preloadGame = {
	preload :function() {

			game.load.image('sky','img/sky.png');
			game.load.image('ground','img/kahoy3.png');
			game.load.image('grounded','img/blocks.png');
			game.load.image('bg','img/cover.png');
			game.load.image('coin','img/we.png');
			game.load.image('fire','img/fire.png');

			game.load.spritesheet('explode','img/explode.png',150,128);
			game.load.spritesheet('dude','img/4.png',32,48);
			game.load.spritesheet("button","img/btn-jump.png",100,100);
			game.load.spritesheet("button1","img/btn-left.png",100,100);
			game.load.spritesheet("button2","img/btn-right.png",100,100);
			//game.load.spritesheet("pause","img/tigil.png",100,100);

			//game.load.image('btn', 'img/qwe.png');
		    game.load.image('title','img/harap.png',800,600);
			game.load.image('start','img/start.png');
			game.load.image('about','img/btn-about.png');
			game.load.image('back2','img/back.png');
			
			game.load.image('btn_paused', 'img/pause2.png');
			game.load.image('btn_pause', 'img/pause.png');
			
			
			game.load.image('gameover1','img/times.png');
			game.load.image('tiu','img/tgameover.png');

			game.load.spritesheet('enemy', 'img/manok1.png', 32, 48);
			game.load.spritesheet('enemy1', 'img/manok2.png', 32, 48);
			game.load.spritesheet('enemy2', 'img/manok3.png', 32, 48);
			game.load.spritesheet('enemy3', 'img/manok4.png', 32, 48);
			game.load.spritesheet('enemy4', 'img/manok5.png', 32, 48);
			game.load.spritesheet('enemy5', 'img/manok6.png', 32, 48);
			game.load.spritesheet('enemy6', 'img/manok6.png', 32, 48);
			game.load.spritesheet('enemy7', 'img/manok6.png', 32, 48);

			game.load.audio("bgmusic","audio/countryside.mp3");
			game.load.audio('yay', 'audio/FIREBALL.wav');
			game.load.audio('boo', 'audio/scra.mp3');
			game.load.audio('waa', 'audio/bad.mp3');
			
	},
	create:function(){
			game.state.start('menuGame');
	},
}
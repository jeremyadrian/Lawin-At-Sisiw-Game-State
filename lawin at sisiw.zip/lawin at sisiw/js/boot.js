bootGame = {
	create:function(){
		game.physics.startSystem(Phaser.Physics.ARCADE);
		game.world.setBounds(0,0,boundsRight,0);
		
		keyboard = game.input.keyboard.createCursorKeys();
		
		game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
		game.scale.forceLandscape = true;
		game.scale.pageAlignHorizontally = true;
		
		
		
		game.state.start('preloadGame');
		
		},
}
menuGame = {
	create:function(){
		title = game.add.sprite(0,0,"title");
		//laro = game.add.button(80,500,"laro",this.laro);
		start = game.add.button(game.width/2.4, game.height/1.6, "start", this.start);
		about = game.add.button(game.width/2.4,450,"about",this.about);
		//help = game.add.button(80,500,"help",this.help);
		
	},
	update:function(){
	},
	start:function(){
		game.state.start("playGame");
	},
	about:function(){
		game.state.start("aboutGame");
	},
	/*help:function(){
		game.state.start("helpGame");
	},*/
}
	